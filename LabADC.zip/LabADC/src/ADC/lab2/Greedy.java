/**
@author TODO
@email  TODO
*/

package ADC.lab2;

import ADC.Task;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bruce
 */
public class Greedy extends Task {
    
    /**
     * Total number of objects from which to choose.
     */
    int numObjects;
    
    /**
     * Maximum total weight of the selected objects.
     */
    int maxWeight;
    
    /**
     * ArrayList containing the items you need to select from.
     */
    ArrayList<Item> items;
    
    float answer = 0.0f;
    
    class Item implements Comparable {       

        float weight;
        float profit;
        
        @Override
        public String toString() {
            return "Item{" + "weight=" + weight + ", profit=" + profit + ")";
        }
        
        Item(float weight, float profit) {
            this.weight = weight;
            this.profit = profit;
        }
        
        @Override
        public int compareTo(Object o) {
            // TODO (compare objects by their ratio)
            return 0; 
        }     
    }
    
    public Greedy () {
        
    }

    @Override
    public void readInput(String inputFile) {
        
        try (Scanner S = new Scanner((new FileReader(inputFile)))) {
            
            numObjects = S.nextInt();
            maxWeight  = S.nextInt();            
            items = new ArrayList<>(numObjects);
            
            for (int i = 0; i < numObjects; ++i) {
                float wi = S.nextFloat();
                float pi = S.nextFloat();
                items.add(new Item(wi, pi));
            }

        } catch (IOException ex) {
            Logger.getLogger(DP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * TODO:
     * Compute the highest possible profit, assuming you can split each object.
     * Expected Complexity: O(numObjects * log(numObjects))
     */
    
    @Override
    public void solve() {       
    }
    
    @Override
    public void printResult(String outputFile) {
       
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {        
            bw.append(Float.toString(answer));  
            bw.append("\n");
        } catch (IOException ex) {
            Logger.getLogger(DP.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
}
