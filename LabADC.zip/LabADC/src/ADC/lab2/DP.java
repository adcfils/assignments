/*
@author: TODO
@email: TODO
*/
package ADC.lab2;
import ADC.Task;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DP extends Task {

    /**
     * Total number of objects from which to choose.
     */
    int numObjects;
    
    /**
     * Maximum total weight of the selected objects.
     */
    int maxWeight;
    
    /**
        The weight and corresponding profit for each object.
    **/
    int[] weights, profits;

    /**
     * solution[i][j] - the best profit you can get using 'i' objects
     *                  without exceeding weight 'j'
     */
    int[][] solution;
    
    public DP () {
        
    }

    @Override
    public void readInput(String inputFile) {
        
        try (Scanner S = new Scanner((new FileReader(inputFile)))) {
            
            numObjects = S.nextInt();
            maxWeight  = S.nextInt();
            
            weights  = new int[numObjects];
            profits  = new int[numObjects];       
            solution = new int[numObjects][maxWeight + 1];
            
            for (int i = 0; i < numObjects; ++i) {                
                weights[i] = S.nextInt();
                profits[i] = S.nextInt();                
            }
                        
        } catch (IOException ex) {
            Logger.getLogger(DP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Compute the highest possible profit, assuming you can
     * use each object at most once.
     * 
     * Expected Complexity (Time): O(numObjects * maxWeight)
     * 
     * solution[i][j] - the best profit you can get using 'i' objects
     *                  without exceeding weight 'j'
     *   
     * Bonus: Improve the Space complexity to O(maxWeight).
     * 
     * You must store the answer in solution[numObject - 1][maxWeight]
     * (or change the printResult() function).
     */
    
    @Override
    public void solve() {        
        // TODO        
    }

    @Override
    public void printResult(String outputFile) {
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
        
            String answer = Integer.toString(solution[numObjects - 1][maxWeight]);
            bw.append(answer);
                        
        } catch (IOException ex) {
            Logger.getLogger(DP.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }

}
