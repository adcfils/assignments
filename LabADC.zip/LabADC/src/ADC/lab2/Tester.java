/*
    @author Radu Iacob
    @email  radu.iacob23@gmail.com
 */
package ADC.lab2;

public class Tester extends ADC.Tester {
    
    @Override
    public String testsPath() {
        return "./tests/lab2/test";
    }
    
    public void runTestsGreedy() {
        System.out.println("Fractional Knapsack problem");
        runTestsDefault(new Greedy(), 2, 4);
    }

    public void runTestsDP() {        
        System.out.println("Knapsack 1/0 DP problem");
        runTestsDefault(new DP(), 0, 2);
    }
        
    public static void main(String... args) {   
        Tester t = new Tester();
        t.runTestsDP();
        t.runTestsGreedy();
    }
}
