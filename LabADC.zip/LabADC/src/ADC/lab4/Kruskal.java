/*
@author: TODO
@email: TODO
*/

package ADC.lab4;

import java.util.ArrayList;
import java.util.Collections;


public class Kruskal extends MST {

	/* Index of the set that the each node belongs to */ 
	ArrayList<Integer> fatherIdx;
	
	/* Bonus: size/rank of a forest */
	ArrayList<Integer> rank; 
	
	public Kruskal() {

	}

	/* TODO: return the root of the tree the node belongs to */
	/* TODO (bonus): Level Path Compression 
	 * Link every node in the tree directly to the tree
	 */
	public int findRoot(int node) {
		return node;
	}
	
	/* TODO: Merge two forests */
	/* Return true if the merge was successful, false otherwise */
	
	/* TODO (Bonus): Rank compression: 
	 * Take into consideration the size of the two forests when merging.
	 * Set rank for the forest
	 */
	public boolean merge(int node1, int node2) {
		return true;
	}
	
	
	@Override
	public void solve() {

		ArrayList<Edge> minSpanningTree = new ArrayList<>();
		
		/* List storing the immediate parent of a node */
		fatherIdx = new ArrayList<>(graph.numNodes);
		
		/* (Bonus) The rank is the number of nodes from the forest associated with a node */ 
		rank      = new ArrayList<>(graph.numNodes);
        
        /* TODO: Sort edges */
        
        /* TODO: 
         * For each edge
         *  check if you can merge the forests associated with the two nodes
         *  if yes, append the edge to the minimum spanning tree
         */

		mst = minSpanningTree;
	}
}
