package ADC.lab4;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import ADC.Task;

/* Minimum Spanning Tree */
public class MST extends Task {

	Graph graph = new Graph();
	ArrayList<Edge> mst;

	@Override
	public void readInput(String inputFile) {

		/*
		 * Format: numNodes, numEdges 
         * Node1 Node2 Weight -> numEdge lines following this pattern 
         * ...
		 */

		try (Scanner scanner = new Scanner(new File(inputFile), "UTF-8")) {

			graph.numNodes = scanner.nextInt();
			graph.numEdges = scanner.nextInt();

			graph.adjList = new ArrayList<>();
			for (int i = 0; i < graph.numNodes; ++i) {
				graph.adjList.add(new ArrayList<>());
			}
			graph.edges = new ArrayList<>();
			
			
			for (int i = 0; i < graph.numEdges; ++i) {

				int node1 = scanner.nextInt();
				int node2 = scanner.nextInt();
				int weight = scanner.nextInt();

				Edge e = new Edge(node1, node2, weight);
				graph.adjList.get(node1).add(e);
				graph.adjList.get(node2).add(e);
			
				/* For convenience, we store another list with references to edges */
				graph.edges.add(e);
			}
			

		} catch (FileNotFoundException ex) {
			Logger.getLogger(Graph.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	@Override
	public void solve() {
	}

	public void printResult(String outputFile) {

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {

			int treeWeight = this.computeTreeWeight(mst);
			bw.write(String.valueOf(treeWeight));

			bw.write("\n");
			for (Edge e : mst) {
				bw.write(e.toString());
				bw.write("\n");
			}

		} catch (IOException ex) {
			Logger.getLogger(Kruskal.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public int computeTreeWeight(ArrayList<Edge> mst) {
		int answer = 0;
		for (Edge e : mst) {
			answer += e.weight;
		}
		return answer;
	}
}
