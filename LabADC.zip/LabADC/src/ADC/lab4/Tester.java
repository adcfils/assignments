/*
    @author Radu Iacob
    @email  radu.iacob23@gmail.com
 */

package ADC.lab4;

import java.util.concurrent.TimeUnit;

public class Tester extends ADC.Tester {
    
    @Override
    public String testsPath() {
        return "./tests/lab4/test";
    }
    
    public void runTestsKruskal() {        
        System.out.println("Running tests for Kruskal: ");
        runTestsDefault(new Kruskal(), 0, 3);
    }
    
    public void runTestsPrim() {
        System.out.println("Running tests for Prim: ");
        runTestsDefault(new Prim(), 0, 3);
    }
    
    public static void main(String... args) {   
        Tester t = new Tester();
        t.runTestsKruskal();
        t.runTestsPrim();
    }
}
