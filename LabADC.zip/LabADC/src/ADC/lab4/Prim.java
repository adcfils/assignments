/**
@author TODO
@email  TODO
*/

package ADC.lab4;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.PriorityQueue;

/**
 * @author TODO
 */
public class Prim extends MST {

	Prim() {

	}

	class NodeComparator implements Comparator<Integer> {

		ArrayList<Integer> distance;

		NodeComparator(ArrayList<Integer> distance) {
			this.distance = distance;
		}

		@Override
		public int compare(Integer node1, Integer node2) {
			/* TODO: Compare nodes based on distance */
			return 0;
		}
	}

	@Override
	public void solve() {

		ArrayList<Edge> minSpanningTree = new ArrayList<>();
		
		/* Marks node as visited after being added to the MST */
		ArrayList<Boolean> visited 		= new ArrayList<>();

		/* Stores the distance from every node to the current MST */
		ArrayList<Integer> distance 	= new ArrayList<>();	
		
		/* For every node, save the best edge from the current MST to it */
		HashMap<Integer, Edge> linkToNode = new HashMap<>();
		
//		/* TODO: Set visited  to false for every node
//		 * TODO: Set distance to infinite (Integer.MAX_VALUE)
//		 */

//		/* TODO: implement compare() method for the comparator */
		PriorityQueue<Integer> pq = new PriorityQueue<Integer>(graph.numNodes, new NodeComparator(distance));
//
//		/* TODO: insert random node in priority queue */

//		/*
//		 * TODO: 
//		 * Until PQ is not Empty 
//		 * 	Extract node from PQ 
//		 * 	Discard if node was previously visited 
//		 * 
//		 *  Otherwise 
//		 *  	Save link to node in minSpanningTree
//		 *  	For every unvisited neighbour 
//		 *  		Check if you can improve distance from the MST to it 
//		 *  		If yes, add neighbour to PQ (update distance and linkToNode)
//		 */

		mst = minSpanningTree;
	}

}
