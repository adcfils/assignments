/**
 * @author Radu Iacob
 * @email  radu.iacob23@gmail.com
 */

package ADC.lab4;

import java.util.ArrayList;

public class Graph {

	public ArrayList<ArrayList<Edge>> adjList;
	public ArrayList<Edge> edges;
	public int numNodes, numEdges;

	Graph() {

	}

	public String toString() {
		StringBuffer buff = new StringBuffer();
		for (int i = 0; i < numNodes; ++i) {
			buff.append(i + ": " + adjList.get(i));
			buff.append("\n");
		}
		return buff.toString();
	}
}
