/**
 * @author Radu Iacob
 * @email  radu.iacob23@gmail.com
 */

package ADC.lab4;

public class Edge implements Comparable<Edge> {

	public int node1;
	public int node2;
	public int weight;

	Edge(int node1, int node2, int weight) {
		this.node1 = node1;
		this.node2 = node2;
		this.weight = weight;
	}

	public String toString() {
		return "(" + this.node1 + ", " + this.node2 + ", weight: " + this.weight + ")";
	}

	@Override
	public int compareTo(Edge other) {
		// TODO: compare by weight
		return 0;
	}

}
