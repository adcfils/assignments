/*
    @author Radu Iacob
    @email  radu.iacob23@gmail.com
 */

package ADC;

import java.io.FileReader;
import java.io.IOException;
import java.util.Locale;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

abstract public class Tester {
    
    /**
     * @return Path where the specific test files are located
     */
    abstract public String testsPath();
    
    /** 
     * Extract exactly one float value from the specified file.
     * @param file
     * @return 
     */
    public static float extractFloat(String file) {        
        try (Scanner S = new Scanner((new FileReader(file)))) {            
            S.useLocale(Locale.US);
            return S.nextFloat();        
        } catch (IOException ex) {
            Logger.getLogger(Tester.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(1);            
            return -1.0f;
        }
    }
    
    /**
     * Check if the answer is correct by comparing the solution's output and the
     * reference result file.
     * This method assumes the answer is one integer value.
     * @param outFile
     * @param resultFile
     */
    public static void checkAnswerDefault(String outFile, String resultFile) {

        float correct_answer = extractFloat(resultFile);
        float own_answer     = extractFloat(outFile);
                
        if (own_answer == correct_answer) {
            System.out.print("OK! ");
        } else {
            System.out.print("Fail! ");
        }
    }
        
    public static void runDefault(Task T, String inputFile, String outputFile) {
        T.readInput(inputFile);
        T.solve();
        T.printResult(outputFile);
    }
        
    /**
     * Convenience function to easily run every test in a given input range.
     * @param T
     * @param tests_start
     * @param tests_end
     */
    public void runTestsDefault(Task T, int tests_start, int tests_end) {
        
        for (int i = tests_start; i < tests_end; ++i) {
            
            String inputFile  = testsPath() + i + ".in";
            String outputFile = testsPath() + i + ".out";
            String resultFile = testsPath() + i + ".ok";
            
            long startTime = System.nanoTime();
            runDefault(T, inputFile, outputFile);
            long endTime = System.nanoTime();
            
            System.out.print("Test " + i + " result: ");
            checkAnswerDefault(outputFile, resultFile);
            System.out.println("(" + TimeUnit.NANOSECONDS.toMillis(endTime - startTime) + "ms)");
        }
    }
    
}