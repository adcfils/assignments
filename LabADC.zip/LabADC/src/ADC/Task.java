/*
    @author Radu Iacob
    @email  radu.iacob23@gmail.com
 */
package ADC;

public abstract class Task {

    public abstract void readInput(String inputFile);

    public abstract void solve();

    public abstract void printResult(String outputFile);

}
